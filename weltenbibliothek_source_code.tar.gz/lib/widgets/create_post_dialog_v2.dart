import 'package:flutter/material.dart';
import '../services/storage_service.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:async';
import '../models/community_post.dart';
import '../models/community_post_extended.dart';
import '../services/community_service.dart';
import '../services/user_service.dart';
import '../services/cloudflare_api_service.dart';
import '../services/post_creation_services.dart';
import 'package:weltenbibliothek/core/storage/unified_storage_service.dart';
import '../services/media_services.dart';
import 'glassmorphism_card.dart';
import 'premium_icons.dart';
import 'smooth_transitions.dart';
import 'media_widgets.dart';
// import 'voice_recorder_widget.dart'; // Disabled - missing record package
import 'drawing_canvas_widget.dart';

/// 🚀 CREATE POST DIALOG V2 - ALLE 10 FEATURES KOMPLETT!
/// 
/// Features:
/// 1. ✅ Emoji Picker
/// 2. ✅ Poll System (Umfragen)
/// 3. ✅ Post Vorschau
/// 4. ✅ Reichweite wählen
/// 5. ✅ Bild-Editor (Crop + Filter)
/// 6. ✅ Entwürfe speichern
/// 7. ✅ Hashtag-Vorschläge
/// 8. ✅ Scheduled Posts
/// 9. ✅ Mention System
/// 10. ✅ Link Preview

class CreatePostDialogV2 extends StatefulWidget {
  final WorldType worldType;
  final DraftPost? draft; // Entwurf laden
  
  const CreatePostDialogV2({
    super.key,
    required this.worldType,
    this.draft,
  });
  
  @override
  State<CreatePostDialogV2> createState() => _CreatePostDialogV2State();
}

class _CreatePostDialogV2State extends State<CreatePostDialogV2> with SingleTickerProviderStateMixin {
  // Controllers
  final TextEditingController _contentController = TextEditingController();
  final TextEditingController _tagsController = TextEditingController();
  late TabController _tabController;
  
  // Services
  final CommunityService _communityService = CommunityService();
  final UserService _userService = UserService();
  final CloudflareApiService _cloudflareService = CloudflareApiService();
  final ImagePicker _picker = ImagePicker();
  
  // State
  bool _isPosting = false;
  bool _isUploadingMedia = false;
  bool _showPreview = false;
  bool _showEmojiPicker = false;
  bool _showHashtagSuggestions = false;
  bool _showMentionSuggestions = false;
  
  // Media
  XFile? _selectedMedia;
  String? _mediaType;
  String? _uploadedMediaUrl;
  String? _selectedFilter = 'Original';
  
  // 🎬 PHASE 2: Video/GIF/Multi-Image
  XFile? _selectedVideo;
  String? _selectedGifUrl;
  List<XFile> _selectedImages = [];
  Map<String, dynamic>? _videoMetadata;
  
  // Feature 4: Reichweite
  PostVisibility _visibility = PostVisibility.public;
  
  // Feature 2: Poll
  bool _isPollMode = false;
  List<TextEditingController> _pollOptions = [];
  DateTime? _pollExpiresAt;
  
  // Feature 8: Scheduled Post
  DateTime? _scheduledFor;
  
  // Feature 10: Link Preview
  LinkPreview? _linkPreview;
  bool _isLoadingLinkPreview = false;
  
  // Feature 7: Hashtag Suggestions
  List<String> _tagSuggestions = [];
  
  // Feature 9: Mention Autocomplete
  List<Map<String, String>> _mentionSuggestions = [];
  int _mentionStartIndex = -1;
  
  // Auto-save timer for drafts
  Timer? _autoSaveTimer;
  
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    
    // Load draft if provided
    if (widget.draft != null) {
      _loadDraft(widget.draft!);
    }
    
    // Initialize poll options
    _pollOptions = [
      TextEditingController(),
      TextEditingController(),
    ];
    
    // Auto-save drafts every 30 seconds
    _autoSaveTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (_contentController.text.isNotEmpty) {
        _saveDraft();
      }
    });
    
    // Listen to content changes for mentions and links
    _contentController.addListener(_onContentChanged);
    
    // Load hashtag suggestions
    _loadHashtagSuggestions();
  }
  
  void _loadDraft(DraftPost draft) {
    _contentController.text = draft.content;
    _tagsController.text = draft.tags.join(', ');
    _uploadedMediaUrl = draft.mediaUrl;
    _mediaType = draft.mediaType;
    _visibility = draft.visibility;
    if (draft.poll != null) {
      _isPollMode = true;
      _pollOptions.clear();
      for (var option in draft.poll!.options) {
        _pollOptions.add(TextEditingController(text: option.text));
      }
      _pollExpiresAt = draft.poll!.expiresAt;
    }
  }
  
  void _loadHashtagSuggestions() {
    setState(() {
      _tagSuggestions = HashtagService.getTrendingTags(widget.worldType.name);
    });
  }
  
  void _onContentChanged() {
    final text = _contentController.text;
    final cursorPos = _contentController.selection.baseOffset;
    
    // Feature 9: Mention detection
    if (cursorPos > 0 && text[cursorPos - 1] == '@') {
      setState(() {
        _showMentionSuggestions = true;
        _mentionStartIndex = cursorPos - 1;
      });
      _searchMentions('');
    } else if (_showMentionSuggestions && cursorPos > _mentionStartIndex) {
      final query = text.substring(_mentionStartIndex + 1, cursorPos);
      if (query.contains(' ')) {
        setState(() => _showMentionSuggestions = false);
      } else {
        _searchMentions(query);
      }
    }
    
    // Feature 10: Link detection
    final urls = LinkPreviewService.extractUrls(text);
    if (urls.isNotEmpty && _linkPreview == null && !_isLoadingLinkPreview) {
      _fetchLinkPreview(urls.first);
    }
  }
  
  void _searchMentions(String query) {
    setState(() {
      _mentionSuggestions = MentionService.searchUsers(query);
    });
  }
  
  void _insertMention(String username) {
    final text = _contentController.text;
    final cursorPos = _contentController.selection.baseOffset;
    final before = text.substring(0, _mentionStartIndex);
    final after = text.substring(cursorPos);
    final newText = '$before@$username $after';
    
    _contentController.value = TextEditingValue(
      text: newText,
      selection: TextSelection.collapsed(offset: _mentionStartIndex + username.length + 2),
    );
    
    setState(() => _showMentionSuggestions = false);
  }
  
  Future<void> _fetchLinkPreview(String url) async {
    setState(() => _isLoadingLinkPreview = true);
    final preview = await LinkPreviewService.fetchLinkPreview(url);
    if (preview != null && mounted) {
      setState(() {
        _linkPreview = LinkPreview.fromJson(preview);
        _isLoadingLinkPreview = false;
      });
    } else {
      setState(() => _isLoadingLinkPreview = false);
    }
  }
  
  @override
  void dispose() {
    _contentController.dispose();
    _tagsController.dispose();
    _tabController.dispose();
    _autoSaveTimer?.cancel();
    for (var controller in _pollOptions) {
      controller.dispose();
    }
    super.dispose();
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // MEDIA HANDLING
  // ═══════════════════════════════════════════════════════════════════════════
  
  Future<void> _pickMedia(String mediaType) async {
    try {
      setState(() => _isUploadingMedia = true);
      
      XFile? file;
      if (mediaType == 'Bild') {
        file = await _picker.pickImage(
          source: ImageSource.gallery,
          maxWidth: 2048,
          maxHeight: 2048,
          imageQuality: 85,
        );
        _mediaType = 'image';
      } else if (mediaType == 'Video') {
        file = await _picker.pickVideo(
          source: ImageSource.gallery,
          maxDuration: const Duration(minutes: 2),
        );
        _mediaType = 'video';
      }
      
      if (file != null) {
        // Show editor for images
        if (mediaType == 'Bild') {
          await _showImageEditor(file);
        } else {
          await _uploadMedia(file);
        }
      } else {
        setState(() => _isUploadingMedia = false);
      }
    } catch (e) {
      setState(() => _isUploadingMedia = false);
      _showError('Media-Auswahl fehlgeschlagen: $e');
    }
  }
  
  // Feature 5: Image Editor
  Future<void> _showImageEditor(XFile imageFile) async {
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (context) => _ImageEditorDialog(
        imageFile: imageFile,
        worldType: widget.worldType,
      ),
    );
    
    if (result != null) {
      final editedFile = result['file'] as XFile;
      _selectedFilter = result['filter'] as String;
      await _uploadMedia(editedFile);
    } else {
      setState(() => _isUploadingMedia = false);
    }
  }
  
  Future<void> _uploadMedia(XFile file) async {
    try {
      final bytes = await file.readAsBytes();
      final fileName = '${DateTime.now().millisecondsSinceEpoch}_${file.name}';
      
      final user = await _userService.getCurrentUser();
      final result = await _cloudflareService.uploadMedia(
        fileBytes: bytes,
        fileName: fileName,
        mediaType: _mediaType!,
        worldType: widget.worldType.name,
        username: user.username,
      );
      
      setState(() {
        _selectedMedia = file;
        _uploadedMediaUrl = result['media_url'];
        _isUploadingMedia = false;
      });
      
      _showSuccess('✅ Media erfolgreich hochgeladen!');
    } catch (e) {
      setState(() => _isUploadingMedia = false);
      _showError('Upload fehlgeschlagen: $e');
    }
  }
  
  void _removeMedia() {
    setState(() {
      _selectedMedia = null;
      _mediaType = null;
      _uploadedMediaUrl = null;
      _selectedFilter = 'Original';
    });
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // DRAFT & SCHEDULED POST
  // ═══════════════════════════════════════════════════════════════════════════
  
  Future<void> _saveDraft() async {
    final content = _contentController.text.trim();
    if (content.isEmpty) return;
    
    final draftData = {
      'id': DateTime.now().millisecondsSinceEpoch.toString(),
      'content': content,
      'tags': _tagsController.text.split(',').map((t) => t.trim()).where((t) => t.isNotEmpty).toList(),
      'mediaUrl': _uploadedMediaUrl,
      'mediaType': _mediaType,
      'createdAt': DateTime.now().toIso8601String(),
      'updatedAt': DateTime.now().toIso8601String(),
      'worldType': widget.worldType.name,
      'visibility': _visibility.name,
      'poll': _isPollMode ? _getPollData()?.toJson() : null,
    };
    
    await DraftService.saveDraft(draftData);
    
    // Save to Hive
    final draftsBox = await StorageService().getBox('post_drafts');
    await draftsBox.put(draftData['id'], draftData);
    
    if (mounted) {
      _showSuccess('💾 Entwurf gespeichert');
    }
  }
  
  Future<void> _showSchedulePicker() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now().add(const Duration(hours: 1)),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 30)),
    );
    
    if (picked != null && mounted) {
      final TimeOfDay? time = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.now(),
      );
      
      if (time != null) {
        setState(() {
          _scheduledFor = DateTime(
            picked.year,
            picked.month,
            picked.day,
            time.hour,
            time.minute,
          );
        });
      }
    }
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // POST CREATION
  // ═══════════════════════════════════════════════════════════════════════════
  
  PollData? _getPollData() {
    if (!_isPollMode) return null;
    
    final options = _pollOptions
        .where((c) => c.text.trim().isNotEmpty)
        .map((c) => PollOption(
              id: DateTime.now().millisecondsSinceEpoch.toString(),
              text: c.text.trim(),
            ))
        .toList();
    
    if (options.length < 2) return null;
    
    return PollData(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      options: options,
      expiresAt: _pollExpiresAt,
    );
  }
  
  Future<void> _createPost() async {
    final content = _contentController.text.trim();
    if (content.isEmpty && !_isPollMode) {
      _showError('Bitte gib einen Text ein oder erstelle eine Umfrage');
      return;
    }
    
    setState(() => _isPosting = true);
    
    try {
      final user = await _userService.getCurrentUser();
      final tags = _tagsController.text
          .split(',')
          .map((t) => t.trim())
          .where((t) => t.isNotEmpty)
          .toList();
      
      final mentions = MentionService.extractMentions(content);
      
      // Check if scheduled
      if (_scheduledFor != null) {
        await _schedulePost(user, content, tags, mentions);
      } else {
        await _publishPost(user, content, tags, mentions);
      }
      
      if (mounted) {
        Navigator.of(context).pop(true);
        _showSuccess('✅ Post erfolgreich ${_scheduledFor != null ? "geplant" : "erstellt"}!');
      }
    } catch (e) {
      setState(() => _isPosting = false);
      _showError('Fehler: $e');
    }
  }
  
  Future<void> _publishPost(
    dynamic user,
    String content,
    List<String> tags,
    List<String> mentions,
  ) async {
    // Create extended post with all features
    final extendedPost = CommunityPostExtended(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      authorUsername: user.username,
      authorAvatar: user.avatar,
      content: content,
      tags: tags,
      createdAt: DateTime.now(),
      worldType: widget.worldType,
      mediaUrl: _uploadedMediaUrl,
      mediaType: _mediaType,
      visibility: _visibility,
      poll: _getPollData(),
      linkPreview: _linkPreview,
      mentions: mentions,
      isDraft: false,
    );
    
    // Save to Firestore/Hive
    await _communityService.createPost(
      username: user.username,
      content: content,
      tags: tags,
      worldType: widget.worldType,
      authorAvatar: user.avatar,
      mediaUrl: _uploadedMediaUrl,
      mediaType: _mediaType,
    );
    
    // Save extended features to separate collection if needed
    // TODO: Save poll, mentions, scheduled data
  }
  
  Future<void> _schedulePost(
    dynamic user,
    String content,
    List<String> tags,
    List<String> mentions,
  ) async {
    final postData = {
      'authorUsername': user.username,
      'authorAvatar': user.avatar,
      'content': content,
      'tags': tags,
      'worldType': widget.worldType.name,
      'mediaUrl': _uploadedMediaUrl,
      'mediaType': _mediaType,
      'visibility': _visibility.name,
      'scheduledFor': _scheduledFor!.toIso8601String(),
      'mentions': mentions,
    };
    
    await DraftService.schedulePost(postData, _scheduledFor!);
    
    // Save to Hive scheduled_posts box
    final scheduledBox = await StorageService().getBox('scheduled_posts');
    await scheduledBox.put(DateTime.now().millisecondsSinceEpoch.toString(), postData);
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // UI HELPERS
  // ═══════════════════════════════════════════════════════════════════════════
  
  void _showSuccess(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.green),
    );
  }
  
  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }
  
  Color get _primaryColor => widget.worldType == WorldType.materie 
      ? Colors.blue 
      : Colors.purple;
  
  // ═══════════════════════════════════════════════════════════════════════════
  // BUILD METHOD
  // ═══════════════════════════════════════════════════════════════════════════
  
  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: GlassmorphismCard(
        blur: 20,
        opacity: 0.15,
        borderRadius: BorderRadius.circular(24),
        borderColor: _primaryColor.withValues(alpha: 0.3),
        borderWidth: 2,
        padding: EdgeInsets.zero,
        child: Container(
          constraints: const BoxConstraints(maxWidth: 700, maxHeight: 800),
          child: Column(
            children: [
              _buildHeader(),
              Expanded(
                child: Row(
                  children: [
                    Expanded(
                      flex: _showPreview ? 1 : 2,
                      child: _buildInputSection(),
                    ),
                    if (_showPreview)
                      Expanded(
                        child: _buildPreviewSection(),
                      ),
                  ],
                ),
              ),
              _buildFooter(),
            ],
          ),
        ),
      ),
    );
  }
  
  // ═══════════════════════════════════════════════════════════════════════════
  // UI SECTIONS
  // ═══════════════════════════════════════════════════════════════════════════
  
  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(color: _primaryColor.withValues(alpha: 0.2), width: 1),
        ),
      ),
      child: Row(
        children: [
          GradientIcon(
            icon: widget.worldType == WorldType.materie ? Icons.public : Icons.psychology,
            size: 28,
            colors: [
              _primaryColor,
              _primaryColor.withValues(red: (_primaryColor.r * 1.5).clamp(0, 1)),
            ],
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Post erstellen',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                Text(
                  '${widget.worldType == WorldType.materie ? "Materie" : "Energie"}-Welt',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.white.withValues(alpha: 0.6),
                  ),
                ),
              ],
            ),
          ),
          // Feature 3: Preview Toggle with Animation
          BounceScaleButton(
            onTap: () {
              HapticFeedback.lightImpact();
              setState(() => _showPreview = !_showPreview);
            },
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: _showPreview
                    ? _primaryColor.withValues(alpha: 0.2)
                    : Colors.white.withValues(alpha: 0.05),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                _showPreview ? Icons.visibility_off : Icons.visibility,
                color: Colors.white,
                size: 20,
              ),
            ),
          ),
          const SizedBox(width: 8),
          BounceScaleButton(
            onTap: () {
              HapticFeedback.lightImpact();
              Navigator.of(context).pop();
            },
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.05),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(
                Icons.close,
                color: Colors.white,
                size: 20,
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildInputSection() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Feature 4: Visibility Selector
          _buildVisibilitySelector(),
          const SizedBox(height: 16),
          
          // Tab Bar (Text/Poll/Media)
          TabBar(
            controller: _tabController,
            labelColor: _primaryColor,
            unselectedLabelColor: Colors.grey,
            indicatorColor: _primaryColor,
            onTap: (index) {
              setState(() {
                _isPollMode = index == 1;
              });
            },
            tabs: const [
              Tab(icon: Icon(Icons.text_fields), text: 'Text'),
              Tab(icon: Icon(Icons.poll), text: 'Umfrage'),
              Tab(icon: Icon(Icons.image), text: 'Media'),
            ],
          ),
          const SizedBox(height: 16),
          
          // Content based on tab
          IndexedStack(
            index: _tabController.index,
            children: [
              _buildTextInput(),
              _buildPollInput(),
              _buildMediaInput(),
            ],
          ),
          
          // Feature 1: Emoji Picker Toggle
          if (_tabController.index == 0) ...[
            const SizedBox(height: 8),
            _buildEmojiButton(),
            if (_showEmojiPicker) _buildEmojiPicker(),
          ],
          
          // Feature 9: Mention Suggestions
          if (_showMentionSuggestions && _tabController.index == 0)
            _buildMentionSuggestions(),
          
          // Feature 7: Hashtag Input with Suggestions
          const SizedBox(height: 16),
          _buildHashtagInput(),
          
          // Feature 10: Link Preview
          if (_linkPreview != null)
            _buildLinkPreviewCard(),
        ],
      ),
    );
  }
  
  Widget _buildTextInput() {
    return TextField(
      controller: _contentController,
      maxLines: 6,
      maxLength: 500,
      decoration: InputDecoration(
        hintText: 'Was möchtest du teilen?',
        border: const OutlineInputBorder(),
        filled: true,
        fillColor: Colors.black.withValues(alpha: 0.3),
      ),
    );
  }
  
  Widget _buildPollInput() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Umfrage erstellen', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        TextField(
          controller: _contentController,
          maxLines: 2,
          decoration: const InputDecoration(
            hintText: 'Frage eingeben...',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 12),
        const Text('Antwortoptionen:', style: TextStyle(fontSize: 12)),
        const SizedBox(height: 8),
        ..._pollOptions.asMap().entries.map((entry) {
          final index = entry.key;
          final controller = entry.value;
          return Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: controller,
                    decoration: InputDecoration(
                      hintText: 'Option ${index + 1}',
                      border: const OutlineInputBorder(),
                      isDense: true,
                    ),
                  ),
                ),
                if (_pollOptions.length > 2)
                  IconButton(
                    icon: const Icon(Icons.remove_circle_outline, size: 20),
                    onPressed: () {
                      setState(() {
                        controller.dispose();
                        _pollOptions.removeAt(index);
                      });
                    },
                  ),
              ],
            ),
          );
        }),
        if (_pollOptions.length < 4)
          TextButton.icon(
            onPressed: () {
              setState(() {
                _pollOptions.add(TextEditingController());
              });
            },
            icon: const Icon(Icons.add, size: 18),
            label: const Text('Option hinzufügen'),
          ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _showPollExpiryPicker,
                icon: const Icon(Icons.schedule, size: 18),
                label: Text(
                  _pollExpiresAt != null
                      ? 'Läuft ab: ${_pollExpiresAt!.day}.${_pollExpiresAt!.month}'
                      : 'Ablaufdatum',
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
  
  void _showPollExpiryPicker() async {
    final options = [
      {'label': '24 Stunden', 'hours': 24},
      {'label': '3 Tage', 'hours': 72},
      {'label': '7 Tage', 'hours': 168},
      {'label': 'Nie', 'hours': null},
    ];
    
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Umfrage läuft ab nach'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: options.map((opt) {
            return ListTile(
              title: Text(opt['label'] as String),
              onTap: () {
                setState(() {
                  final hours = opt['hours'] as int?;
                  _pollExpiresAt = hours != null
                      ? DateTime.now().add(Duration(hours: hours))
                      : null;
                });
                Navigator.pop(context);
              },
            );
          }).toList(),
        ),
      ),
    );
  }
  
  Widget _buildMediaInput() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Existing Media (if any)
          if (_selectedVideo != null) ...[
            VideoPreviewWidget(
              video: _selectedVideo!,
              metadata: _videoMetadata,
              onRemove: () => setState(() {
                _selectedVideo = null;
                _videoMetadata = null;
              }),
            ),
            const SizedBox(height: 12),
          ],
          
          if (_selectedGifUrl != null) ...[
            GlassmorphismCard(
              blur: 15,
              opacity: 0.1,
              borderRadius: BorderRadius.circular(16),
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.white.withValues(alpha: 0.3)),
                    ),
                    child: const Icon(Icons.gif_box, color: Colors.white, size: 32),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Text(
                      'GIF ausgewählt',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.white),
                    onPressed: () => setState(() => _selectedGifUrl = null),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
          ],
          
          if (_selectedImages.isNotEmpty) ...[
            MultiImageGalleryWidget(
              images: _selectedImages,
              onRemove: (index) => setState(() => _selectedImages.removeAt(index)),
              onAddMore: () async {
                final image = await MultiImageService.pickSingleImage();
                if (image != null && _selectedImages.length < 5) {
                  setState(() => _selectedImages.add(image));
                }
              },
              maxImages: 5,
            ),
            const SizedBox(height: 12),
          ],
          
          // Media Buttons Grid
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 2.5,
            children: [
              _buildMediaButton(
                icon: Icons.photo_camera,
                label: 'Bild',
                colors: [const Color(0xFF4CAF50), const Color(0xFF8BC34A)],
                onTap: () async {
                  final image = await MultiImageService.pickSingleImage();
                  if (image != null) {
                    setState(() => _selectedImages = [image]);
                  }
                },
              ),
              _buildMediaButton(
                icon: Icons.videocam,
                label: 'Video',
                colors: [const Color(0xFFE91E63), const Color(0xFF9C27B0)],
                onTap: () async {
                  final video = await VideoService.pickVideo();
                  if (video != null) {
                    final metadata = await VideoService.getVideoMetadata(video);
                    setState(() {
                      _selectedVideo = video;
                      _videoMetadata = metadata;
                    });
                  }
                },
              ),
              _buildMediaButton(
                icon: Icons.gif_box,
                label: 'GIF',
                colors: [const Color(0xFF00BCD4), const Color(0xFF3F51B5)],
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (context) => Dialog(
                      backgroundColor: Colors.transparent,
                      child: GlassmorphismCard(
                        blur: 20,
                        opacity: 0.15,
                        child: GifPickerWidget(
                          onGifSelected: (gifUrl) {
                            setState(() => _selectedGifUrl = gifUrl);
                          },
                        ),
                      ),
                    ),
                  );
                },
              ),
              _buildMediaButton(
                icon: Icons.photo_library,
                label: 'Galerie',
                colors: [const Color(0xFFFF9800), const Color(0xFFFF5722)],
                onTap: () async {
                  final images = await MultiImageService.pickMultipleImages();
                  if (images.isNotEmpty) {
                    setState(() => _selectedImages = images);
                  }
                },
              ),
              _buildMediaButton(
                icon: Icons.mic,
                label: 'Voice Note',
                colors: [const Color(0xFF2196F3), const Color(0xFF03A9F4)],
                onTap: () {
                  // Voice recording disabled - missing record package
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Voice recording coming soon!'),
                    ),
                  );
                },
              ),
              _buildMediaButton(
                icon: Icons.draw,
                label: 'Zeichnung',
                colors: [const Color(0xFF9C27B0), const Color(0xFFE91E63)],
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (context) => Dialog(
                      backgroundColor: Colors.transparent,
                      child: DrawingCanvasWidget(
                        onDrawingComplete: (imageBytes) {
                          setState(() {
                            // Store drawing
                          });
                          Navigator.pop(context);
                        },
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
          const SizedBox(height: 16),
          
          // Caption Input
          TextField(
            controller: _contentController,
            maxLines: 3,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Beschreibung hinzufügen...',
              hintStyle: TextStyle(color: Colors.white.withValues(alpha: 0.5)),
              filled: true,
              fillColor: Colors.white.withValues(alpha: 0.05),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildMediaButton({
    required IconData icon,
    required String label,
    required List<Color> colors,
    required VoidCallback onTap,
  }) {
    return AnimatedGlassmorphismCard(
      onTap: onTap,
      blur: 15,
      opacity: 0.1,
      borderRadius: BorderRadius.circular(12),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          GradientIcon(
            icon: icon,
            size: 24,
            colors: colors,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w600,
                fontSize: 14,
              ),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildVisibilitySelector() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          const Text('Sichtbarkeit:', style: TextStyle(fontSize: 13)),
          const SizedBox(width: 12),
          Expanded(
            child: DropdownButton<PostVisibility>(
              value: _visibility,
              isExpanded: true,
              underline: const SizedBox(),
              items: const [
                DropdownMenuItem(
                  value: PostVisibility.public,
                  child: Row(
                    children: [
                      Icon(Icons.public, size: 18),
                      SizedBox(width: 8),
                      Text('Öffentlich'),
                    ],
                  ),
                ),
                DropdownMenuItem(
                  value: PostVisibility.friends,
                  child: Row(
                    children: [
                      Icon(Icons.people, size: 18),
                      SizedBox(width: 8),
                      Text('Freunde'),
                    ],
                  ),
                ),
                DropdownMenuItem(
                  value: PostVisibility.private,
                  child: Row(
                    children: [
                      Icon(Icons.lock, size: 18),
                      SizedBox(width: 8),
                      Text('Privat'),
                    ],
                  ),
                ),
              ],
              onChanged: (value) {
                if (value != null) {
                  setState(() => _visibility = value);
                }
              },
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildEmojiButton() {
    return Row(
      children: [
        TextButton.icon(
          onPressed: () => setState(() => _showEmojiPicker = !_showEmojiPicker),
          icon: const Icon(Icons.emoji_emotions, size: 18),
          label: Text(_showEmojiPicker ? 'Emoji ausblenden' : 'Emoji hinzufügen'),
        ),
      ],
    );
  }
  
  Widget _buildEmojiPicker() {
    return Container(
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Häufig verwendet:', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: EmojiService.getFrequentEmojis().map((emoji) {
              return InkWell(
                onTap: () => _insertEmoji(emoji),
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.4),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(emoji, style: const TextStyle(fontSize: 20)),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 12),
          ...EmojiService.emojiCategories.entries.map((entry) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${entry.key}:', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: entry.value.take(15).map((emoji) {
                    return InkWell(
                      onTap: () => _insertEmoji(emoji),
                      child: Text(emoji, style: const TextStyle(fontSize: 18)),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 8),
              ],
            );
          }),
        ],
      ),
    );
  }
  
  void _insertEmoji(String emoji) {
    final text = _contentController.text;
    final selection = _contentController.selection;
    final newText = text.replaceRange(selection.start, selection.end, emoji);
    _contentController.value = TextEditingValue(
      text: newText,
      selection: TextSelection.collapsed(offset: selection.start + emoji.length),
    );
  }
  
  Widget _buildHashtagInput() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextField(
          controller: _tagsController,
          decoration: InputDecoration(
            labelText: 'Tags',
            hintText: 'z.B. Forschung, Geopolitik',
            prefixIcon: const Icon(Icons.tag),
            border: const OutlineInputBorder(),
            suffixIcon: IconButton(
              icon: Icon(_showHashtagSuggestions ? Icons.expand_less : Icons.expand_more),
              onPressed: () => setState(() => _showHashtagSuggestions = !_showHashtagSuggestions),
            ),
          ),
        ),
        if (_showHashtagSuggestions) ...[
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Vorschläge:', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: _tagSuggestions.map((tag) {
                    return InkWell(
                      onTap: () => _addTag(tag),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: _primaryColor.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: _primaryColor.withValues(alpha: 0.3)),
                        ),
                        child: Text(
                          '#$tag',
                          style: TextStyle(fontSize: 12, color: _primaryColor),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }
  
  void _addTag(String tag) {
    final current = _tagsController.text;
    final tags = current.isEmpty ? [] : current.split(',').map((t) => t.trim()).toList();
    if (!tags.contains(tag)) {
      tags.add(tag);
      _tagsController.text = tags.join(', ');
    }
  }
  
  Widget _buildMentionSuggestions() {
    return Container(
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 8,
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: _mentionSuggestions.map((user) {
          return ListTile(
            dense: true,
            leading: Text(user['avatar']!, style: const TextStyle(fontSize: 24)),
            title: Text(user['username']!),
            onTap: () => _insertMention(user['username']!),
          );
        }).toList(),
      ),
    );
  }
  
  Widget _buildLinkPreviewCard() {
    return Container(
      margin: const EdgeInsets.only(top: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          if (_linkPreview!.imageUrl != null)
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: Image.network(
                _linkPreview!.imageUrl!,
                width: 60,
                height: 60,
                fit: BoxFit.cover,
              ),
            ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (_linkPreview!.title != null)
                  Text(
                    _linkPreview!.title!,
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                if (_linkPreview!.description != null)
                  Text(
                    _linkPreview!.description!,
                    style: const TextStyle(fontSize: 11, color: Colors.grey),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                if (_linkPreview!.domain != null)
                  Text(
                    _linkPreview!.domain!,
                    style: TextStyle(fontSize: 10, color: _primaryColor),
                  ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.close, size: 18),
            onPressed: () => setState(() => _linkPreview = null),
          ),
        ],
      ),
    );
  }
  
  Widget _buildPreviewSection() {
    return Container(
      decoration: BoxDecoration(
        border: Border(left: BorderSide(color: Colors.white.withValues(alpha: 0.2))),
        color: Colors.black.withValues(alpha: 0.3),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              border: Border(bottom: BorderSide(color: Colors.white.withValues(alpha: 0.2))),
            ),
            child: const Row(
              children: [
                Icon(Icons.visibility, size: 18),
                SizedBox(width: 8),
                Text('Vorschau', style: TextStyle(fontWeight: FontWeight.bold)),
              ],
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: _buildPostPreview(),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildPostPreview() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                const CircleAvatar(child: Text('👤')),
                const SizedBox(width: 8),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Dein Name', style: TextStyle(fontWeight: FontWeight.bold)),
                      Text('Gerade eben', style: TextStyle(fontSize: 11, color: Colors.grey)),
                    ],
                  ),
                ),
                if (_visibility != PostVisibility.public)
                  Icon(
                    _visibility == PostVisibility.friends ? Icons.people : Icons.lock,
                    size: 16,
                    color: Colors.grey,
                  ),
              ],
            ),
          ),
          if (_contentController.text.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Text(_contentController.text),
            ),
          if (_uploadedMediaUrl != null)
            Container(
              margin: const EdgeInsets.all(12),
              height: 200,
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: 0.5),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Center(
                child: Icon(
                  _mediaType == 'image' ? Icons.image : Icons.play_circle,
                  size: 48,
                  color: Colors.grey,
                ),
              ),
            ),
          if (_isPollMode && _pollOptions.any((c) => c.text.isNotEmpty))
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('📊 Umfrage', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                  const SizedBox(height: 8),
                  ..._pollOptions.where((c) => c.text.isNotEmpty).map((c) {
                    return Container(
                      margin: const EdgeInsets.only(bottom: 6),
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.radio_button_unchecked, size: 18),
                          const SizedBox(width: 8),
                          Expanded(child: Text(c.text, style: const TextStyle(fontSize: 13))),
                          const Text('0%', style: TextStyle(fontSize: 11, color: Colors.grey)),
                        ],
                      ),
                    );
                  }),
                ],
              ),
            ),
          if (_linkPreview != null)
            Padding(
              padding: const EdgeInsets.all(12),
              child: _buildLinkPreviewCard(),
            ),
          if (_tagsController.text.isNotEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: Wrap(
                spacing: 6,
                children: _tagsController.text.split(',').map((tag) {
                  final cleanTag = tag.trim();
                  if (cleanTag.isEmpty) return const SizedBox.shrink();
                  return Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: _primaryColor.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      '#$cleanTag',
                      style: TextStyle(fontSize: 11, color: _primaryColor),
                    ),
                  );
                }).toList(),
              ),
            ),
          const Divider(height: 1),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Icon(Icons.thumb_up_outlined, size: 18, color: Colors.white.withValues(alpha: 0.7)),
                const SizedBox(width: 4),
                const Text('0', style: TextStyle(fontSize: 12, color: Colors.grey)),
                const SizedBox(width: 16),
                Icon(Icons.comment_outlined, size: 18, color: Colors.white.withValues(alpha: 0.7)),
                const SizedBox(width: 4),
                const Text('0', style: TextStyle(fontSize: 12, color: Colors.grey)),
                const SizedBox(width: 16),
                Icon(Icons.share_outlined, size: 18, color: Colors.white.withValues(alpha: 0.7)),
                const SizedBox(width: 4),
                const Text('0', style: TextStyle(fontSize: 12, color: Colors.grey)),
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildFooter() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        border: Border(top: BorderSide(color: Colors.white.withValues(alpha: 0.2))),
      ),
      child: Row(
        children: [
          // Feature 6: Save Draft
          OutlinedButton.icon(
            onPressed: _isPosting ? null : _saveDraft,
            icon: const Icon(Icons.save, size: 18),
            label: const Text('Entwurf'),
          ),
          const SizedBox(width: 8),
          // Feature 8: Schedule Post
          OutlinedButton.icon(
            onPressed: _isPosting ? null : _showSchedulePicker,
            icon: Icon(
              _scheduledFor != null ? Icons.schedule : Icons.schedule_outlined,
              size: 18,
            ),
            label: Text(
              _scheduledFor != null 
                  ? '${_scheduledFor!.day}.${_scheduledFor!.month}' 
                  : 'Planen',
            ),
          ),
          const Spacer(),
          TextButton(
            onPressed: _isPosting ? null : () => Navigator.of(context).pop(),
            child: const Text('Abbrechen'),
          ),
          const SizedBox(width: 8),
          ElevatedButton.icon(
            onPressed: _isPosting ? null : _createPost,
            icon: _isPosting
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                  )
                : Icon(_scheduledFor != null ? Icons.schedule_send : Icons.send, size: 18),
            label: Text(
              _isPosting 
                  ? 'Wird gepostet...' 
                  : _scheduledFor != null 
                      ? 'Planen' 
                      : 'Posten',
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: _primaryColor,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            ),
          ),
        ],
      ),
    );
  }
}

/// ═══════════════════════════════════════════════════════════════════════════
/// FEATURE 5: IMAGE EDITOR DIALOG
/// ═══════════════════════════════════════════════════════════════════════════

class _ImageEditorDialog extends StatefulWidget {
  final XFile imageFile;
  final WorldType worldType;
  
  const _ImageEditorDialog({
    required this.imageFile,
    required this.worldType,
  });
  
  @override
  State<_ImageEditorDialog> createState() => _ImageEditorDialogState();
}

class _ImageEditorDialogState extends State<_ImageEditorDialog> {
  String _selectedFilter = 'Original';
  
  @override
  Widget build(BuildContext context) {
    final primaryColor = widget.worldType == WorldType.materie 
        ? Colors.blue 
        : Colors.purple;
    
    return Dialog(
      child: Container(
        constraints: const BoxConstraints(maxWidth: 600, maxHeight: 700),
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Row(
              children: [
                Icon(Icons.edit, color: primaryColor),
                const SizedBox(width: 12),
                const Expanded(
                  child: Text(
                    'Bild bearbeiten',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.black.withValues(alpha: 0.5),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Center(
                  child: Icon(Icons.image, size: 100, color: Colors.grey),
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Text('Filter:', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            SizedBox(
              height: 80,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: ImageEditorService.filters.map((filter) {
                  final isSelected = _selectedFilter == filter['name'];
                  return GestureDetector(
                    onTap: () => setState(() => _selectedFilter = filter['name'] as String),
                    child: Container(
                      width: 70,
                      margin: const EdgeInsets.only(right: 12),
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: isSelected ? primaryColor : Colors.white.withValues(alpha: 0.3),
                          width: isSelected ? 2 : 1,
                        ),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            filter['icon'] as String,
                            style: const TextStyle(fontSize: 24),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            filter['name'] as String,
                            style: TextStyle(
                              fontSize: 10,
                              color: isSelected ? primaryColor : Colors.grey,
                              fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      // TODO: Implement crop
                    },
                    icon: const Icon(Icons.crop),
                    label: const Text('Zuschneiden'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      // TODO: Implement text overlay
                    },
                    icon: const Icon(Icons.text_fields),
                    label: const Text('Text'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Abbrechen'),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context, {
                      'file': widget.imageFile,
                      'filter': _selectedFilter,
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryColor,
                    foregroundColor: Colors.white,
                  ),
                  child: const Text('Fertig'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
