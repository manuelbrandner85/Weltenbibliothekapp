/// 🎤 VOICE MESSAGE SERVICE - PLATFORM EXPORT
/// Exports the full implementation for all platforms (Web + Android)
library;

// ✅ USE FULL IMPLEMENTATION: Voice Messages work on ALL platforms
export 'voice_message_service.dart';
