/// Platform stub for conditional imports
library;

class PlatformService {
  static bool get isWeb => false;
  static bool get isAndroid => true;
}
