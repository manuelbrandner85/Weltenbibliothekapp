import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

// 🆕 RECHERCHE-STATUS STATE MACHINE
enum RechercheStatus {
  idle,
  loading,
  sourcesFound,
  analysisReady,
  done,
  error
}

class RechercheScreenSSE extends StatefulWidget {
  const RechercheScreenSSE({super.key});

  @override
  State<RechercheScreenSSE> createState() => _RechercheScreenSSEState();
}

class _RechercheScreenSSEState extends State<RechercheScreenSSE> {
  final TextEditingController controller = TextEditingController();
  
  RechercheStatus status = RechercheStatus.idle;
  
  String? resultText;
  String? validationError;
  
  // Progress-Tracking
  double progress = 0.0;
  String currentPhase = "";
  List<Map<String, dynamic>> intermediateResults = [];

  // 🆕 AUTO-RETRY-LOGIC
  int retryCount = 0;
  static const int maxRetries = 3;

  // 🆕 LIVE-UPDATE-LOG
  List<String> liveLog = [];

  String? validateQuery(String query) {
    final trimmed = query.trim();
    
    if (trimmed.isEmpty) {
      return "⚠️ Bitte Suchbegriff eingeben";
    }
    
    if (trimmed.length < 3) {
      return "⚠️ Mindestens 3 Zeichen erforderlich";
    }
    
    if (trimmed.length > 100) {
      return "⚠️ Maximal 100 Zeichen erlaubt";
    }
    
    if (trimmed.contains(RegExp(r'[<>{}]'))) {
      return "⚠️ Ungültige Sonderzeichen";
    }
    
    return null;
  }

  void transitionTo(RechercheStatus newStatus, {String? phase, double? progressValue}) {
    setState(() {
      status = newStatus;
      if (phase != null) currentPhase = phase;
      if (progressValue != null) progress = progressValue;
    });
  }

  // 🆕 SSE-RECHERCHE MIT LIVE-UPDATES
  Future<void> startRechercheSSE() async {
    final error = validateQuery(controller.text);
    if (error != null) {
      setState(() {
        validationError = error;
      });
      return;
    }
    
    setState(() {
      validationError = null;
      intermediateResults = [];
      liveLog = [];
      resultText = null;
    });

    transitionTo(RechercheStatus.loading, phase: "Verbinde mit Server...", progressValue: 0.1);

    final uri = Uri.parse(
      "https://weltenbibliothek-worker.brandy13062.workers.dev?q=${Uri.encodeComponent(controller.text.trim())}"
    );

    try {
      // 🆕 SSE REQUEST
      final request = http.Request('GET', uri);
      final streamedResponse = await request.send().timeout(const Duration(seconds: 120));

      if (streamedResponse.statusCode == 429) {
        transitionTo(RechercheStatus.error);
        throw Exception("⏱️ Zu viele Anfragen. Bitte warte 60 Sekunden.");
      }

      if (streamedResponse.statusCode != 200) {
        transitionTo(RechercheStatus.error);
        throw Exception("Worker nicht erreichbar (HTTP ${streamedResponse.statusCode})");
      }

      // 🆕 STREAM PROCESSING
      final stream = streamedResponse.stream
          .transform(utf8.decoder)
          .transform(const LineSplitter());

      await for (final line in stream) {
        if (!line.startsWith('data: ')) continue;

        try {
          final data = jsonDecode(line.substring(6));
          await _handleSSEUpdate(data);
        } catch (e) {
          debugPrint("SSE Parse Error: $e");
        }
      }

      // Reset retry counter on success
      retryCount = 0;

    } catch (e) {
      transitionTo(RechercheStatus.error, phase: "Fehler aufgetreten", progressValue: 0.0);
      
      // AUTO-RETRY-LOGIC
      if (retryCount < maxRetries && !e.toString().contains("429")) {
        retryCount++;
        setState(() {
          resultText = "❌ Fehler: $e\n\n⚡ Auto-Retry in 3 Sekunden... (Versuch $retryCount/$maxRetries)";
        });
        
        Future.delayed(const Duration(seconds: 3), () {
          if (mounted && status == RechercheStatus.error) {
            startRechercheSSE();
          }
        });
      } else {
        setState(() {
          resultText = "❌ Fehler: $e\n\n🔄 Bitte manuell erneut versuchen";
          retryCount = 0;
        });
      }
    }
  }

  // 🆕 SSE UPDATE HANDLER
  Future<void> _handleSSEUpdate(Map<String, dynamic> data) async {
    final phase = data['phase'];
    final status = data['status'];
    final message = data['message'] ?? '';

    // Add to live log
    setState(() {
      liveLog.add("[$phase] $status: $message");
    });

    switch (phase) {
      case 'web':
        if (status == 'started') {
          transitionTo(RechercheStatus.loading, 
            phase: "🌐 Webquellen werden geprüft...", 
            progressValue: 0.2);
        } else if (status == 'done') {
          setState(() {
            intermediateResults.add({
              'source': '🌐 Webquellen',
              'type': '${data['count']} gefunden'
            });
          });
          transitionTo(RechercheStatus.sourcesFound, 
            phase: message, 
            progressValue: 0.4);
        }
        break;

      case 'documents':
        if (status == 'started') {
          setState(() {
            currentPhase = "📦 Archive werden durchsucht...";
            progress = 0.5;
          });
        } else if (status == 'done') {
          setState(() {
            intermediateResults.add({
              'source': '📦 Archive',
              'type': '${data['count']} Dokumente gefunden'
            });
          });
          setState(() {
            currentPhase = message;
            progress = 0.6;
          });
        } else if (status == 'skipped') {
          setState(() {
            intermediateResults.add({
              'source': '📦 Archive',
              'type': 'übersprungen'
            });
          });
        }
        break;

      case 'media':
        if (status == 'started') {
          setState(() {
            currentPhase = "🎬 Medien werden gesucht...";
            progress = 0.7;
          });
        } else if (status == 'done') {
          setState(() {
            intermediateResults.add({
              'source': '🎬 Medien',
              'type': '${data['count']} gefunden'
            });
          });
        } else if (status == 'skipped') {
          setState(() {
            intermediateResults.add({
              'source': '🎬 Medien',
              'type': 'übersprungen'
            });
          });
        }
        break;

      case 'analysis':
        if (status == 'started') {
          transitionTo(RechercheStatus.analysisReady, 
            phase: message, 
            progressValue: 0.8);
        } else if (status == 'done') {
          setState(() {
            currentPhase = message;
            progress = 0.95;
          });
          
          // Fallback-Indikator
          if (data['isFallback'] == true) {
            setState(() {
              intermediateResults.add({
                'source': '🆘 Fallback aktiviert',
                'type': 'theoretische Einordnung'
              });
            });
          }
        }
        break;

      case 'final':
        if (status == 'done') {
          transitionTo(RechercheStatus.done, phase: "Fertig!", progressValue: 1.0);
          
          // Format final result
          final analyse = data['analyse'];
          final query = data['query'];
          
          String formatted = "═══════════════════════════════════\n";
          formatted += "RECHERCHE: $query\n";
          formatted += "═══════════════════════════════════\n\n";
          
          if (data['status'] == "fallback" && data['message'] != null) {
            formatted += "⚠️ HINWEIS:\n${data['message']}\n\n";
          }
          
          final sourcesStatus = data['sourcesStatus'];
          if (sourcesStatus != null) {
            formatted += "📊 QUELLEN-STATUS:\n";
            formatted += "Web-Quellen: ${sourcesStatus['web'] ?? 0}\n";
            formatted += "Dokumente: ${sourcesStatus['documents'] ?? 0}\n";
            formatted += "Medien: ${sourcesStatus['media'] ?? 0}\n\n";
          }
          
          if (analyse != null) {
            if (analyse["fallback"] == true || analyse["mitDaten"] == false) {
              formatted += "⚠️ ANALYSE OHNE AUSREICHENDE PRIMÄRDATEN\n\n";
            }
            
            formatted += analyse["inhalt"] ?? "Keine Analyse verfügbar";
            formatted += "\n\n";
            formatted += "─────────────────────────────────\n";
            formatted += "Timestamp: ${analyse["timestamp"]}\n";
          } else {
            formatted += "Keine Analyse verfügbar\n";
          }
          
          setState(() {
            resultText = formatted;
          });
        }
        break;

      case 'error':
        transitionTo(RechercheStatus.error);
        setState(() {
          resultText = "❌ Fehler: $message";
        });
        break;
    }
  }

  Color getStatusColor() {
    switch (status) {
      case RechercheStatus.idle:
        return Colors.grey;
      case RechercheStatus.loading:
        return Colors.blue;
      case RechercheStatus.sourcesFound:
        return Colors.orange;
      case RechercheStatus.analysisReady:
        return Colors.purple;
      case RechercheStatus.done:
        return Colors.green;
      case RechercheStatus.error:
        return Colors.red;
    }
  }

  String getStatusText() {
    switch (status) {
      case RechercheStatus.idle:
        return "Bereit";
      case RechercheStatus.loading:
        return "LOADING - Verbinde...";
      case RechercheStatus.sourcesFound:
        return "SOURCES_FOUND - ${intermediateResults.length} Quellen";
      case RechercheStatus.analysisReady:
        return "ANALYSIS_READY - Analyse läuft";
      case RechercheStatus.done:
        return "DONE - Abgeschlossen";
      case RechercheStatus.error:
        return "ERROR - Fehler aufgetreten";
    }
  }

  @override
  Widget build(BuildContext context) {
    final isSearching = status == RechercheStatus.loading || 
                        status == RechercheStatus.sourcesFound || 
                        status == RechercheStatus.analysisReady;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Recherche (SSE) – Live-Updates"),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: getStatusColor().withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: getStatusColor(), width: 2),
                ),
                child: Text(
                  status.name.toUpperCase(),
                  style: TextStyle(
                    color: getStatusColor(),
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // STATUS-BADGE
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: getStatusColor().withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: getStatusColor(), width: 1),
              ),
              child: Row(
                children: [
                  Icon(
                    status == RechercheStatus.done ? Icons.check_circle :
                    status == RechercheStatus.error ? Icons.error :
                    status == RechercheStatus.idle ? Icons.search :
                    Icons.sync,
                    color: getStatusColor(),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      getStatusText(),
                      style: TextStyle(
                        color: getStatusColor(),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            
            // Eingabefeld
            TextField(
              controller: controller,
              decoration: InputDecoration(
                labelText: "Suchbegriff eingeben",
                helperText: "Min. 3 Zeichen, max. 100 Zeichen",
                errorText: validationError,
                border: const OutlineInputBorder(),
              ),
              onChanged: (value) {
                setState(() {
                  validationError = validateQuery(value);
                });
              },
            ),
            const SizedBox(height: 16),
            
            // Button
            ElevatedButton.icon(
              onPressed: (isSearching || validateQuery(controller.text) != null)
                  ? null
                  : startRechercheSSE,
              icon: const Icon(Icons.stream),
              label: const Text("Recherche starten (SSE)"),
            ),
            const SizedBox(height: 24),

            // Progress-Anzeige
            if (isSearching) ...[
              LinearProgressIndicator(
                value: progress,
                backgroundColor: Colors.grey[300],
                valueColor: AlwaysStoppedAnimation<Color>(getStatusColor()),
              ),
              const SizedBox(height: 8),
              Text(
                currentPhase,
                style: TextStyle(
                  fontSize: 14,
                  fontStyle: FontStyle.italic,
                  color: getStatusColor(),
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
            ],

            // 🆕 LIVE-LOG
            if (isSearching && liveLog.isNotEmpty) ...[
              const Text(
                "📡 Live-Updates:",
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Container(
                height: 150,
                decoration: BoxDecoration(
                  border: Border.all(color: getStatusColor()),
                  borderRadius: BorderRadius.circular(8),
                  color: Colors.black.withValues(alpha: 0.05),
                ),
                child: ListView.builder(
                  itemCount: liveLog.length,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      child: Text(
                        liveLog[index],
                        style: const TextStyle(fontSize: 11, fontFamily: 'monospace'),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 16),
            ],

            // Zwischenergebnisse
            if (isSearching && intermediateResults.isNotEmpty) ...[
              const Text(
                "📊 Gefundene Quellen:",
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Container(
                height: 100,
                decoration: BoxDecoration(
                  border: Border.all(color: getStatusColor()),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: ListView.builder(
                  itemCount: intermediateResults.length,
                  itemBuilder: (context, index) {
                    final result = intermediateResults[index];
                    return ListTile(
                      dense: true,
                      leading: Icon(Icons.check_circle, color: getStatusColor(), size: 16),
                      title: Text(
                        result['source'] ?? 'Quelle ${index + 1}',
                        style: const TextStyle(fontSize: 12),
                      ),
                      subtitle: Text(
                        result['type'] ?? '',
                        style: const TextStyle(fontSize: 10),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 16),
            ],

            // Ergebnis
            if (status == RechercheStatus.done || status == RechercheStatus.error)
              Expanded(
                child: SingleChildScrollView(
                  child: SelectableText(
                    resultText ?? '',
                    style: const TextStyle(fontSize: 14),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    // 🧹 PHASE B: Proper resource disposal
    super.dispose();
  }
}
