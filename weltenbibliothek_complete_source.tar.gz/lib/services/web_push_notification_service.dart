/// Web Push Notification Service - Platform Switcher
library;
export 'web_push_notification_service_stub.dart'
  if (dart.library.html) 'web_push_notification_service_web.dart';
